from __future__ import annotations
import math
import os
import moviepy.editor as mp
from typing import TYPE_CHECKING, ClassVar

if TYPE_CHECKING:
    from ..app import App


class Editor:
    version: str = "1.0"
    parent: ClassVar[App]

    def __init__(self) -> None:
        pass

    def backgroundVideoFun(self):
        if len(self.parent.inputBackgroundVideo) > 0:
            main_video = mp.VideoFileClip(self.parent.inputBackgroundVideo)
            overlay_video = self.parent.clip.resize(
                width=main_video.w - (main_video.w * 0.1))

            main_duration = main_video.duration
            overlay_duration = overlay_video.duration
            if main_duration < overlay_duration:
                looped_clips = []
                num_loops = int(overlay_duration / main_duration) + 1

                for _ in range(num_loops):
                    looped_clips.append(main_video)

                main_video = mp.concatenate(looped_clips)
                main_video = main_video.subclip(0, overlay_duration)

            final_clip = mp.CompositeVideoClip(
                [main_video.set_pos('center'), overlay_video.set_pos('center')]).set_duration(overlay_video.duration)
            return final_clip.set_duration(self.parent.clip.duration)
        else:
            return self.parent.clip

    def cropVideoFun(self):
        if len(self.parent.inputCropVideo) > 0:
            txtInputList = self.parent.inputCropVideo.split(",")

            left = float(txtInputList[0]) * self.parent.clip.w
            right = float(txtInputList[1]) * self.parent.clip.w
            top = float(txtInputList[2]) * self.parent.clip.h
            bottom = float(txtInputList[3]) * self.parent.clip.h

            return self.parent.clip.crop(x1=left, x2=self.parent.clip.w - right, y1=top, y2=self.parent.clip.h - bottom)
        else:
            return self.parent.clip

    def resizeVideoFun(self):
        if len(self.parent.inputResizeVideo) > 0:
            txtInputList = self.parent.inputResizeVideo.split(",")
            target_width = txtInputList[0]
            target_height = txtInputList[1]
            return self.parent.clip.resize((target_width, target_height))
        else:
            return self.parent.clip

    def overlayImageFun(self):
        if len(self.parent.inputImgPath) > 0:
            overlay_image = mp.ImageClip(self.parent.inputImgPath)
            txtInputList = self.parent.inputImagePosition.split(",")
            percentage = int(txtInputList[0])
            # Specify the desired width
            new_width = (percentage / 100) * self.parent.clip.size[0]
            # Calculate the proportional height
            new_height = int(
                new_width * overlay_image.size[1] / overlay_image.size[0])
            overlay_image = overlay_image.resize(
                width=new_width, height=new_height)

            opacity = 0.9
            overlay_image = overlay_image.set_opacity(opacity)

            spacing = 20

            txtInputList = self.parent.inputImagePosition.split(",")

            xPos = int(txtInputList[1])
            yPos = int(txtInputList[2])

            if xPos == 1:
                # Align to the right
                x_position = self.parent.clip.size[0] - \
                    overlay_image.size[0] - spacing
            else:
                x_position = spacing
            if yPos == 1:
                # Align to the bottom
                y_position = self.parent.clip.size[1] - \
                    overlay_image.size[1] - spacing
            else:
                y_position = spacing
            overlay_image = overlay_image.set_position(
                (x_position, y_position))
            final_clip = mp.CompositeVideoClip(
                [self.parent.clip, overlay_image])
            return final_clip.set_duration(self.parent.clip.duration)
        else:
            return self.parent.clip

    def subClipFun(self):
        if len(self.parent.inputSubclip) > 0:
            txtInputList = self.parent.inputSubclip.split(",")
            video_duration = self.parent.clip.duration
            start_time = int(txtInputList[0])  # Start time in seconds
            end_time = int(txtInputList[1])
            if start_time < 0 or end_time > video_duration or start_time >= end_time:
                print("Invalid start or end time. Please choose valid values.")
                return self.parent.clip
            else:
                return self.parent.clip.subclip(start_time, end_time)
        else:
            return self.parent.clip

    def text_position(t):
        x = 400  # x-coordinate of the text (centered horizontally)
        # y-coordinate of the text (moves up and down)
        y = 300 + 100 * (t % 2) - 50
        return (x, y)

    def textFun(self):
        if len(self.parent.inputText) > 0:
            txtLists = [self.parent.clip]
            txtInputList = self.parent.inputText.split(",")
            font_size = int(min(self.parent.clip.size) * 0.05)

            def center_percent(txt_width):
                center_x = self.parent.clip.size[0] // 2
                text_x = center_x - txt_width // 2
                return ((text_x / self.parent.clip.size[0]) * 100) / 100

            if len(txtInputList) >= 1 and len(txtInputList[0]) > 0:
                textTop = mp.TextClip(txtInputList[0], fontsize=font_size, color='white',
                                      bg_color='transparent', align='center').set_duration(self.parent.clip.duration)

                textTop = textTop.set_position(
                    (center_percent(textTop.w), 0.10), relative=True)
                txtLists.append(textTop)
                print("Text added on top")

            if len(txtInputList) >= 2 and len(txtInputList[1]) > 0:

                center_x = self.parent.clip.size[0] * 0.40
                center_y = self.parent.clip.size[1] * 0.50

                def move_in_circle(t):
                    amplitude_y = 100  # Adjust the amplitude of the vertical movement
                    amplitude_x = 100  # Adjust the amplitude of the horizontal movement
                    # Controls the speed of the circular movement
                    frequency = 2 * math.pi / self.parent.clip.duration

                    x = center_x + amplitude_x * math.cos(frequency * t)
                    # y = center_y + amplitude_y * (2*t/self.parent.clip.duration - 1)
                    if t < self.parent.clip.duration / 2:
                        y = center_y + amplitude_y * \
                            (2*t/self.parent.clip.duration - 1)
                    else:
                        y = center_y - amplitude_y * \
                            (2*t/self.parent.clip.duration - 1)
                    return x, y

                textCenter = mp.TextClip(txtInputList[1], fontsize=font_size, color='white', align='center').set_duration(
                    self.parent.clip.duration).set_opacity(0.3).set_position(lambda t: move_in_circle(t))
                txtLists.append(textCenter)
                print("Text added on center")

            if len(txtInputList) == 3 and len(txtInputList[2]) > 0:
                textBottom = mp.TextClip(
                    txtInputList[2], fontsize=font_size, color='white', bg_color='transparent', align='center').set_duration(self.parent.clip.duration)

                textBottom = textBottom.set_position(
                    (center_percent(textBottom.w), 0.85), relative=True)
                txtLists.append(textBottom)
                print("Text added on bottom")

            if len(txtLists) > 1:
                return mp.CompositeVideoClip(clips=txtLists)
            else:
                print("U inputed text wrong format..")
                return self.parent.clip
        else:
            return self.parent.clip

    def mp3Fun(self):
        if len(self.parent.inputMp3Path) > 0 and os.path.exists(self.parent.inputMp3Path):
            txtInputList = self.parent.inputVolume.split(",")
            original_audio = self.parent.clip.audio
            original_audio = original_audio.volumex(float(txtInputList[0]))
            # Load the audio self.parent.clip
            audio = mp.AudioFileClip(self.parent.inputMp3Path)
            # Check if the audio is longer than the video
            if audio.duration > self.parent.clip.duration:
                # Trim the audio to match the duration of the video
                audio = audio.subclip(0, self.parent.clip.duration)
                # Fade out the audio towards the end
                audio = audio.audio_fadeout(5)
            else:
                # Repeat the audio to match the duration of the video
                audio = mp.afx.audio_loop(
                    audio, duration=self.parent.clip.duration)

            new_audio = audio.volumex(float(txtInputList[1]))
            final_audio = mp.CompositeAudioClip([original_audio, new_audio])

            return self.parent.clip.set_audio(final_audio)
        else:
            return self.parent.clip

    def flipFun(self):
        if self.parent.inputFlip is True:
            return self.parent.clip.fx(mp.vfx.mirror_x)
        else:
            return self.parent.clip

    def muteFun(self):
        if self.parent.inputMute is True:
            return self.parent.clip.without_audio()
        else:
            return self.parent.clip

    def speedFun(self):
        if self.parent.inputSpeed != 1:
            return self.parent.clip.fx(mp.vfx.speedx, self.parent.inputSpeed)
        else:
            return self.parent.clip

    def resizeFun(self):
        if self.parent.inputResize != 1:
            background_color = (0, 0, 0)  # Example: Red background (RGB value)
            background_clip = mp.ColorClip(
                size=self.parent.clip.size, col=background_color, duration=self.parent.clip.duration)
            return mp.CompositeVideoClip([background_clip, self.parent.clip.resize(self.parent.inputResize).set_position(("center", "center"))])
        else:
            return self.parent.clip

    def colorFun(self):
        if self.parent.inputColor != 1:
            return self.parent.clip.fx(mp.vfx.colorx, self.parent.inputColor)
        else:
            return self.parent.clip
