from __future__ import annotations
import math
import os
import moviepy.editor as mp
from typing import TYPE_CHECKING, ClassVar
import tempfile
from .helper import generate_name, get_random_mp3_file
import moviepy.video.fx.all as vfx
if TYPE_CHECKING:
    from ..app import App


class Editor:
    version: str = "1.3"
    parent: ClassVar[App]
    clip = mp.VideoFileClip

    def __init__(self, filePath) -> None:
        self.filePath = filePath

    def run(self):
        # Load a video clip
        # , target_resolution=(self.parent.inputHeightVideo, self.parent.inputWidthVideo)
        self.clip = mp.VideoFileClip(
            self.filePath, audio=self.parent.inputNotMute,  resize_algorithm="fast_bilinear")

        meta = self.clip
        NEW_PATH = f"{self.parent.folderName}/{os.path.basename(self.filePath)}"

        # Extract a portion of the video
        if len(self.parent.inputCropVideo) > 0:
            self.clip = self.cropVideoFun()
            
        if self.parent.inputRotateVideo > 0:
            self.clip = self.rotateVideoFun()

        if self.parent.inputResize != 1:
            self.clip = self.resizeFun()

        if self.parent.inputHeightVideo > 0 or self.parent.inputWidthVideo > 0:
            self.clip = self.resizeVideoFun()

        if len(self.parent.inputBackgroundVideo) > 0:
            self.clip = self.backgroundVideoFun()

        if self.parent.inputSpeed != 1:
            self.clip = self.speedFun()

        # if self.parent.inputNotMute is True:
        #     self.clip = self.muteFun()

        if self.parent.inputFlip is True:
            self.clip = self.flipFun()

        if self.parent.inputColor != 1:
            self.clip = self.colorFun()

        if len(self.parent.inputMp3Path) > 0 or len(self.parent.inputMp3Folder) > 0:
            if self.parent.selectMp3Random:
                mp3Path = get_random_mp3_file(self.parent.inputMp3Folder)
            else:
                mp3Path = self.parent.inputMp3Path
            self.clip = self.mp3Fun(mp3Path=mp3Path)

        if len(self.parent.inputText) > 0:
            self.clip = self.textFun()

        if len(self.parent.inputSubclip) > 0:
            self.clip = self.subClipFun()

        if len(self.parent.inputImgPath) > 0:
            self.clip = self.overlayImageFun()

        # Save the extracted portion to a new file
        temp_dir = tempfile.gettempdir()
        self.clip.write_videofile(NEW_PATH,
                                  temp_audiofile=f"{temp_dir}/{generate_name()}",
                                  codec="libx264",
                                  bitrate=None,
                                  preset=self.parent.videoPreset,
                                  ffmpeg_params=[
                                    "-metadata", "title={}".format(self.parent.videoMetaTitle),
                                    "-movflags", "faststart",
                                    # "-c:a", "aac"
                                  ],
                                  fps=meta.fps,
                                  threads=self.parent.batchSize
                                  )
        self.clip.close()

    def backgroundVideoFun(self):
        main_video = mp.VideoFileClip(self.parent.inputBackgroundVideo)
        overlay_video = self.clip.resize(
            width=main_video.w - (main_video.w * 0.05))

        main_duration = main_video.duration
        overlay_duration = overlay_video.duration
        if main_duration < overlay_duration:
            looped_clips = []
            num_loops = int(overlay_duration / main_duration) + 1

            for _ in range(num_loops):
                looped_clips.append(main_video)

            main_video = mp.concatenate(looped_clips)
            main_video = main_video.subclip(0, overlay_duration)

        final_clip = mp.CompositeVideoClip(
            [main_video.set_pos('center'), overlay_video.set_pos('center')]).set_duration(overlay_video.duration)
        return final_clip.set_duration(self.clip.duration)

    def cropVideoFun(self):
        txtInputList = self.parent.inputCropVideo.split(",")
        left = float(txtInputList[0]) * self.clip.w
        right = float(txtInputList[1]) * self.clip.w
        top = float(txtInputList[2]) * self.clip.h
        bottom = float(txtInputList[3]) * self.clip.h
        return self.clip.crop(x1=left, x2=self.clip.w - right, y1=top, y2=self.clip.h - bottom)

    def resizeVideoFun(self):
        return self.clip.resize((self.parent.inputWidthVideo, self.parent.inputHeightVideo))

    def rotateVideoFun(self):
        rotateClip = self.clip.fx(vfx.rotate, angle=self.parent.inputRotateVideo)
        return rotateClip

    def overlayImageFun(self):
        overlay_image = mp.ImageClip(self.parent.inputImgPath)
        txtInputList = self.parent.inputImagePosition.split(",")
        percentage = int(txtInputList[0])
        # Specify the desired width
        new_width = (percentage / 100) * self.clip.size[0]
        # Calculate the proportional height
        new_height = int(
            new_width * overlay_image.size[1] / overlay_image.size[0])
        overlay_image = overlay_image.resize(
            width=new_width, height=new_height)

        opacity = 0.9
        overlay_image = overlay_image.set_opacity(opacity)

        spacing = 20

        txtInputList = self.parent.inputImagePosition.split(",")

        xPos = int(txtInputList[1])
        yPos = int(txtInputList[2])

        if xPos == 1:
            # Align to the right
            x_position = self.clip.size[0] - \
                overlay_image.size[0] - spacing
        else:
            x_position = spacing
        if yPos == 1:
            # Align to the bottom
            y_position = self.clip.size[1] - \
                overlay_image.size[1] - spacing
        else:
            y_position = spacing
        overlay_image = overlay_image.set_position(
            (x_position, y_position))
        final_clip = mp.CompositeVideoClip(
            [self.clip, overlay_image])
        return final_clip.set_duration(self.clip.duration)

    def subClipFun(self):
        txtInputList = self.parent.inputSubclip.split(",")
        video_duration = self.clip.duration
        start_time = int(txtInputList[0])  # Start time in seconds
        end_time = int(txtInputList[1])
        if start_time < 0 or end_time > video_duration or start_time >= end_time:
            print("Invalid start or end time. Please choose valid values.")
            return self.clip
        else:
            return self.clip.subclip(start_time, end_time)

    def text_position(t):
        x = 400  # x-coordinate of the text (centered horizontally)
        # y-coordinate of the text (moves up and down)
        y = 300 + 100 * (t % 2) - 50
        return (x, y)

    def textFun(self):
        txtLists = [self.clip]
        txtInputList = self.parent.inputText.split(",")
        font_size = int(min(self.clip.size) * 0.05)

        def center_percent(txt_width):
            center_x = self.clip.size[0] // 2
            text_x = center_x - txt_width // 2
            return ((text_x / self.clip.size[0]) * 100) / 100

        if len(txtInputList) >= 1 and len(txtInputList[0]) > 0:
            textTop = mp.TextClip(txtInputList[0], fontsize=font_size, color='white',
                                  bg_color='transparent', align='center').set_duration(self.clip.duration)

            textTop = textTop.set_position(
                (center_percent(textTop.w), 0.10), relative=True)
            txtLists.append(textTop)
            print("Text added on top")

        if len(txtInputList) >= 2 and len(txtInputList[1]) > 0:

            center_x = self.clip.size[0] * 0.40
            center_y = self.clip.size[1] * 0.50

            def move_in_circle(t):
                amplitude_y = 100  # Adjust the amplitude of the vertical movement
                amplitude_x = 100  # Adjust the amplitude of the horizontal movement
                # Controls the speed of the circular movement
                frequency = 2 * math.pi / self.clip.duration

                x = center_x + amplitude_x * math.cos(frequency * t)
                # y = center_y + amplitude_y * (2*t/self.clip.duration - 1)
                if t < self.clip.duration / 2:
                    y = center_y + amplitude_y * \
                        (2*t/self.clip.duration - 1)
                else:
                    y = center_y - amplitude_y * \
                        (2*t/self.clip.duration - 1)
                return x, y

            textCenter = mp.TextClip(txtInputList[1], fontsize=font_size, color='white', align='center').set_duration(
                self.clip.duration).set_opacity(0.3).set_position(lambda t: move_in_circle(t))
            txtLists.append(textCenter)
            print("Text added on center")

        if len(txtInputList) == 3 and len(txtInputList[2]) > 0:
            textBottom = mp.TextClip(
                txtInputList[2], fontsize=font_size, color='white', bg_color='transparent', align='center').set_duration(self.clip.duration)

            textBottom = textBottom.set_position(
                (center_percent(textBottom.w), 0.85), relative=True)
            txtLists.append(textBottom)
            print("Text added on bottom")

        if len(txtLists) > 1:
            return mp.CompositeVideoClip(clips=txtLists)
        else:
            print("U inputed text wrong format..")
            return self.clip

    def mp3Fun(self, mp3Path):
        txtInputList = self.parent.inputVolume.split(",")
        original_audio = self.clip.audio
        original_audio = original_audio.volumex(float(txtInputList[0]))
        # Load the audio self.clip
        audio = mp.AudioFileClip(mp3Path)
        # Check if the audio is longer than the video
        if audio.duration > self.clip.duration:
            # Trim the audio to match the duration of the video
            audio = audio.subclip(0, self.clip.duration)
            # Fade out the audio towards the end
            audio = audio.audio_fadeout(5)
        else:
            # Repeat the audio to match the duration of the video
            audio = mp.afx.audio_loop(
                audio, duration=self.clip.duration)

        new_audio = audio.volumex(float(txtInputList[1]))
        final_audio = mp.CompositeAudioClip([original_audio, new_audio])

        return self.clip.set_audio(final_audio)

    def flipFun(self):
        return self.clip.fx(mp.vfx.mirror_x)

    def muteFun(self):
        return self.clip.without_audio()

    def speedFun(self):
        return self.clip.fx(mp.vfx.speedx, self.parent.inputSpeed)

    def resizeFun(self):
        background_color = (0, 0, 0)  # Example: Red background (RGB value)
        background_clip = mp.ColorClip(
            size=self.clip.size, col=background_color, duration=self.clip.duration)
        return mp.CompositeVideoClip([background_clip, self.clip.resize(self.parent.inputResize).set_position(("center", "center"))])

    def colorFun(self):
        return self.clip.fx(mp.vfx.colorx, self.parent.inputColor)
