"""
.. include:: ../README.md
"""
__docformat__ = "restructuredtext"
from libs.editor import Editor
