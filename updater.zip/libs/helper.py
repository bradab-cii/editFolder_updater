from datetime import datetime
import os
from tkinter import filedialog

def select_folder(prefix="crushjs"):
    folder_path = filedialog.askdirectory()
    now = datetime.now()
    strFolder = "%s/%s_%s" % (folder_path, prefix,
                              now.strftime("%d-%m-%Y_%H-%M-%S"))
    os.mkdir(strFolder)
    return strFolder


def check_for_mp3_files(folder_path):
    mp3_files_found = False
    if os.path.exists(folder_path) and os.path.isdir(folder_path):
        for file in os.listdir(folder_path):
            if file.lower().endswith('.mp3') or file.lower().endswith('.wav'):
                mp3_files_found = True
                break

    return mp3_files_found

def validate_number_input(prompt, numeric_type):
    while True:
        try:
            if numeric_type == int:
                value = int(input(prompt))
            elif numeric_type == float:
                value = float(input(prompt))
            else:
                raise ValueError("Invalid numeric type specified.")
            return value
        except ValueError:
            print("Invalid input! Please enter a valid", numeric_type.__name__)