from datetime import datetime
import os
import random
import string
from tkinter import filedialog


def select_folder(prefix="crushjs"):
    folder_path = filedialog.askdirectory()
    now = datetime.now()
    strFolder = "%s/%s_%s" % (folder_path, prefix,
                              now.strftime("%d-%m-%Y_%H-%M-%S"))
    os.mkdir(strFolder)
    return strFolder


def generate_name(extention=".mp3", length=10):
    """
    Generates a random name for an MP3 file.

    Args:
        length (int): Length of the generated name (default: 10).

    Returns:
        str: Randomly generated name.
    """
    letters = string.ascii_letters
    digits = string.digits

    # Combine letters and digits to create a pool of characters
    pool = letters + digits

    # Generate a random name using characters from the pool
    name = ''.join(random.choices(pool, k=length))

    # Append the .mp3 extension to the name
    name += extention

    return name


def check_for_mp3_files(folder_path):
    mp3_files_found = False
    if os.path.exists(folder_path) and os.path.isdir(folder_path):
        for file in os.listdir(folder_path):
            if file.lower().endswith('.mp3') or file.lower().endswith('.wav'):
                mp3_files_found = True
                break

    return mp3_files_found

def get_random_mp3_file(folder_path):
    # Check if the folder path exists and is a directory
    if not os.path.exists(folder_path) or not os.path.isdir(folder_path):
        raise ValueError("Invalid folder path or folder does not exist.")

    # Get a list of all files in the folder
    all_files = os.listdir(folder_path)

    # Filter out non-mp3 files
    mp3_files = [file for file in os.listdir(folder_path) if file.lower().endswith('.mp3') or file.lower().endswith('.wav')]

    # Check if there are any mp3 files in the folder
    if not mp3_files:
        raise ValueError("No mp3 files found in the folder.")

    # Choose a random mp3 file from the list
    random_mp3_file = random.choice(mp3_files)

    # Return the absolute path of the random mp3 file
    return os.path.abspath(os.path.join(folder_path, random_mp3_file))