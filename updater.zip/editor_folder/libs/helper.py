from datetime import datetime
import os
import random
import string
from tkinter import filedialog


def select_folder(prefix="crushjs"):
    print("Please ! Choose a folder")
    folder_path = filedialog.askdirectory()
    now = datetime.now()
    strFolder = "%s/%s_%s" % (folder_path, prefix,
                              now.strftime("%d-%m-%Y_%H-%M-%S"))
    os.mkdir(strFolder)
    return strFolder


def generate_name(extention=".mp3", length=10):
    """
    Generates a random name for an MP3 file.

    Args:
        length (int): Length of the generated name (default: 10).

    Returns:
        str: Randomly generated name.
    """
    letters = string.ascii_letters
    digits = string.digits

    # Combine letters and digits to create a pool of characters
    pool = letters + digits

    # Generate a random name using characters from the pool
    name = ''.join(random.choices(pool, k=length))

    # Append the .mp3 extension to the name
    name += extention

    return name
