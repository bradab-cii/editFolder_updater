import os
import zipfile
import requests
from tqdm import tqdm
from editor import Editor


class Updater:
    def __init__(self) -> None:
        self.currentVersion = Editor.version
        print("Current version: ", self.currentVersion)

    def check_for_updates(self) -> bool:
        try:
            # Fetch the latest version number from a remote server
            response = requests.get(
                'https://raw.githubusercontent.com/bradab-cii/editFolder_updater/master/core/version.txt')
            response_data = response.content
            # Print the response data as a decoded string
            latest_version = response_data.strip().decode()
            # Compare the latest version number with the current version number
            if self.currentVersion != latest_version:
                return True
            else:
                return False
        except Exception as e:
            # Handle any exceptions that occur while fetching the latest version number
            print('Error checking for updates:', e)
            # raise Exception("Something went wrong!")

    def update_new_version(self):
        try:
            # Launch the download URL in the user's web browser
            download_url = requests.get(
                'https://github.com/bradab-cii/editFolder_updater/raw/master/updater.zip', stream=True)
            total_size = int(
                download_url.headers.get('content-length', 0))
            block_size = 1024
            FOLDER_APP_PATH = os.getcwd()
            CU_APP_PATH = os.path.join(
                FOLDER_APP_PATH, 'updater.zip')
            with open(CU_APP_PATH, "wb") as f:
                with tqdm(total=total_size, unit='B', unit_scale=True, desc='Updating...') as pbar:
                    for data in download_url.iter_content(block_size):
                        f.write(data)
                        pbar.update(len(data))
                f.flush()   # flush any remaining data to the file
                f.close()   # close the file
            download_url.raise_for_status()
            print("Download completed.")
            with zipfile.ZipFile(CU_APP_PATH, "r") as zip_ref:
                zip_ref.extractall(path=FOLDER_APP_PATH)
            print("Update completed.")
            os.remove(CU_APP_PATH)
        except Exception as e:
            # Handle any exceptions that occur while fetching the latest version number
            print('Error update new version:', e)
            # raise Exception("Something went wrong!")

    def run(self):
        updater = self.check_for_updates()
        if updater == True:
            self.update_new_version()
        else:
            print("Up-to-date")


updater = Updater()
updater.run()
