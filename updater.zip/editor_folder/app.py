from libs import Editor
import tempfile
from tkinter import filedialog, messagebox
import glob
import moviepy.editor as mp
import os
from moviepy.config import change_settings
from dotenv import load_dotenv

from libs.helper import generate_name, select_folder
load_dotenv()
change_settings({
    "IMAGEMAGICK_BINARY": os.getenv("IMAGEMAGICK_BINARY"),
    "FFMPEG_BINARY": os.getenv("FFMPEG_BINARY")
})


class App:
    editor: Editor
    inputSpeed: float = 1
    inputColor: float = 1
    inputResize: float = 1
    inputMp3Path: str = ""
    inputVolume: str = ""
    inputMute: bool = False
    inputFlip: bool = False
    inputText: str = ""
    inputSubclip: str = ""
    inputImgPath: str = ""
    inputImagePosition: str = ""
    inputResizeVideo: str = ""
    inputBackgroundVideo: str = ""
    inputCropVideo: str = ""
    clip = mp.VideoFileClip

    def __init__(self) -> None:
        Editor.parent = self

    def selectOptions(self):
        while True:
            print()
            print("Donate me ABA: 000 702 144 | Sokea Sang")
            print("0. Continue to process")
            print("1. Speed (default = 1)")
            print("2. Color (default = 1)")
            print("3. Resize (default = 1)")
            print("4. Audio")
            print("5. Mute")
            print("6. Flip")
            print("7. Text (default = '','','')")
            print("8. Subclip")
            print("9. Overlay image")
            print("10. Resize video")
            print("11. Background video")
            print("12. Crop video")
            print()
            choice = input("Enter your choice (0-13): ")
            print()
            if choice == "1":
                print("You selected Speed")
                self.inputSpeed = input('Enter speed video: ')
                # Perform the actions for Option 1 here
            elif choice == "2":
                print("You selected Color")
                self.inputColor = input('Enter color video: ')
                # Perform the actions for Option 2 here
            elif choice == "3":
                print("You selected resize")
                self.inputResize = input('Enter resize: ')
                # Perform the actions for Option 2 here
            elif choice == "4":
                print("You selected Audio")
                selector = filedialog.askopenfilenames(
                    filetypes=[("MP3 files", "*.mp3"), ("WAV files", "*.wav")]
                )
                self.inputMp3Path = selector[0]
                self.inputVolume = input(
                    'Enter volume (original, new audio): ')
                # Perform the actions for Option 2 here
            elif choice == "5":
                print("You selected Mute")
                self.inputMute = True
                # Perform the actions for Option 3 here
            elif choice == "6":
                print("You selected Flip")
                self.inputFlip = True
            elif choice == "7":
                print("You selected text")
                self.inputText = input('Enter text: ')
            elif choice == "8":
                print("You selected subclip")
                self.inputSubclip = input('Enter text: ')
            elif choice == "9":
                print("You selected overlay image")
                filetypes = (
                    ('Image files', '*.jpg *.jpeg *.png'),
                    ('All files', '*.*')
                )
                self.inputImgPath = filedialog.askopenfilename(
                    title='Select an image file',
                    initialdir='/',  # Optional: Set initial directory
                    filetypes=filetypes
                )
                self.inputImagePosition = input(
                    'Enter image position (pSize, xPos, yPos): ')
            elif choice == "10":
                print("You selected resize video")
                self.inputResizeVideo = input('Enter text: ')

            elif choice == "11":
                print("You selected background video")
                self.inputBackgroundVideo = filedialog.askopenfilename(
                    filetypes=[("MP3 files", "*.mp4")])
            elif choice == "12":
                print("You selected crop video")
                self.inputCropVideo = input(
                    'Enter text (left,right,top,bottom): ')
            elif choice == "0":
                print("Processing...")
                break
            else:
                print("Invalid choice. Please enter a number from 0 to 13.")
            print()

            self.inputSpeed = float(self.inputSpeed)
            self.inputColor = float(self.inputColor)
            self.inputResize = float(self.inputResize)

    def run(self):
        print("Select folder to edit: ")
        folder_path = filedialog.askdirectory()
        mp4_files = glob.glob(f'{folder_path}/*.mp4')

        print("Select folder to save: ")
        folderName = select_folder()
        # Print the list of MP4 files
        for file_path in mp4_files:
            # Load a video clip
            self.clip = mp.VideoFileClip(file_path)
            self.editor = Editor()
            # Extract a portion of the video
            self.clip = self.editor.cropVideoFun()
            self.clip = self.editor.backgroundVideoFun()
            self.clip = self.editor.speedFun()
            self.clip = self.editor.muteFun()
            self.clip = self.editor.flipFun()
            self.clip = self.editor.colorFun()
            self.clip = self.editor.resizeFun()
            self.clip = self.editor.resizeVideoFun()
            self.clip = self.editor.mp3Fun()
            self.clip = self.editor.textFun()
            self.clip = self.editor.subClipFun()
            self.clip = self.editor.overlayImageFun()
            # Save the extracted portion to a new file
            temp_dir = tempfile.gettempdir()
            self.clip.write_videofile(f"{folderName}/{os.path.basename(file_path)}",
                                      temp_audiofile=f"{temp_dir}/{generate_name()}")

        openFolder = messagebox.askyesno(
            "Download completed", "Do you want to open folder?")
        if openFolder is True:
            os.startfile(folderName)


app = App()
app.selectOptions()
app.run()
