from libs import Editor
from tkinter import filedialog, messagebox
import glob
import os
from moviepy.config import change_settings
from dotenv import load_dotenv
import threading
from libs.helper import select_folder
import curses

load_dotenv()
change_settings({
    "IMAGEMAGICK_BINARY": os.getenv("IMAGEMAGICK_BINARY"),
    "FFMPEG_BINARY": os.getenv("FFMPEG_BINARY")
})

class Colors:
    RESET = '\033[0m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'

class Borders:
    RESET = '\033[0m'
    BORDER = '\033[1m'
    BORDER_COLOR = '\033[94m'

class App:
    editor: Editor
    inputSpeed: float = 1
    inputColor: float = 1
    inputResize: float = 1
    inputMp3Path: str = ""
    inputVolume: str = ""
    inputNotMute: bool = True
    inputFlip: bool = False
    inputText: str = ""
    inputSubclip: str = ""
    inputImgPath: str = ""
    inputImagePosition: str = ""
    inputHeightVideo: int = 1280
    inputWidthVideo: int = 720
    inputBackgroundVideo: str = ""
    inputCropVideo: str = ""
    inputRotateVideo: float = 0
    folderName: str = ""
    videoPreset = "ultrafast"
    videoMetaTitle = "funny videos"
    def __init__(self) -> None:
        Editor.parent = self
    def print_colored(self, text, color):
        print(color + text + Colors.RESET)

    def menu_lists(self):
        self.print_colored('Donate me ABA: 000 702 144 | Sokea Sang', Colors.RED)
        self.print_colored('0. Continue to process', Colors.CYAN)
        self.print_colored('1. Speed (default = 1)', Colors.CYAN)
        self.print_colored('2. Color (default = 1)', Colors.CYAN)
        self.print_colored('3. Resize zoom in or out (default = 1)', Colors.CYAN)
        self.print_colored('4. Audio', Colors.CYAN)
        self.print_colored('5. Mute', Colors.CYAN)
        self.print_colored('6. Flip', Colors.CYAN)
        self.print_colored('7. Text (default = '','','')', Colors.CYAN)
        self.print_colored('8. Subclip', Colors.CYAN)
        self.print_colored('9. Overlay image', Colors.CYAN)
        self.print_colored('10. Resize video (width, height)', Colors.CYAN)
        self.print_colored('11. Background video', Colors.CYAN)
        self.print_colored('12. Crop video', Colors.CYAN)
        # print("13. Rotate video")

    def select_option(self, stdscr, options):
        selected_index = 0
        curses.curs_set(0)  # Hide the cursor
        while True:
            # Clear the terminal screen and display options
            stdscr.clear()
            stdscr.addstr("Use arrow keys (up/down) to select an option:\n\n")
            for i, option in enumerate(options):
                if i == selected_index:
                    stdscr.addstr(f"> {option}\n", curses.A_REVERSE)
                else:
                    stdscr.addstr(f"  {option}\n")
            stdscr.refresh()

            key = stdscr.getch()  # Wait for user input
            if key == curses.KEY_UP:
                selected_index = (selected_index - 1) % len(options)
            elif key == curses.KEY_DOWN:
                selected_index = (selected_index + 1) % len(options)
            elif key == 10:  # 10 is the ASCII code for the Enter key
                return options[selected_index]
            
    def inputIntValidate(self, txt="Enter video", default=720):
        input_width = input(f'{txt} (default = {default}): ')

        if input_width.strip():
            try:
                width = int(input_width)
                return width
            except ValueError:
                print("Invalid input. Using the default width.")

        return default
    def selectOptions(self):
        while True:
            self.menu_lists()
            print()
            choice = input("Enter your choice (0-12): ")
            print()
            if choice == "1":
                print("You selected Speed")
                self.inputSpeed = input('Enter speed video: ')
                # Perform the actions for Option 1 here
            elif choice == "2":
                print("You selected Color")
                self.inputColor = input('Enter color video: ')
                # Perform the actions for Option 2 here
            elif choice == "3":
                print("You selected resize")
                self.inputResize = input('Enter resize: ')
                # Perform the actions for Option 2 here
            elif choice == "4":
                print("You selected Audio")
                selector = filedialog.askopenfilenames(
                    filetypes=[("MP3 files", "*.mp3"), ("WAV files", "*.wav")]
                )
                self.inputMp3Path = selector[0]
                self.inputVolume = input(
                    'Enter volume (original, new audio): ')
                # Perform the actions for Option 2 here
            elif choice == "5":
                print("You selected Mute")
                self.inputNotMute = False
                # Perform the actions for Option 3 here
            elif choice == "6":
                print("You selected Flip")
                self.inputFlip = True
            elif choice == "7":
                print("You selected text")
                self.inputText = input('Enter text: ')
            elif choice == "8":
                print("You selected subclip")
                self.inputSubclip = input('Enter text: ')
            elif choice == "9":
                print("You selected overlay image")
                filetypes = (
                    ('Image files', '*.jpg *.jpeg *.png'),
                    ('All files', '*.*')
                )
                self.inputImgPath = filedialog.askopenfilename(
                    title='Select an image file',
                    initialdir='/',  # Optional: Set initial directory
                    filetypes=filetypes
                )
                self.inputImagePosition = input(
                    'Enter image position (pSize, xPos, yPos): ')
            elif choice == "10":
                print("You selected resize video")
                self.inputWidthVideo = self.inputIntValidate(txt="Enter video width", default=720)
                self.inputHeightVideo = self.inputIntValidate(txt="Enter video height", default=1280)

            elif choice == "11":
                print("You selected background video")
                self.inputBackgroundVideo = filedialog.askopenfilename(
                    filetypes=[("MP3 files", "*.mp4")])
            elif choice == "12":
                print("You selected crop video")
                self.inputCropVideo = input(
                    'Enter text (left,right,top,bottom): ')
            elif choice == "0":
                print("Processing...")
                break
            else:
                print("Invalid choice. Please enter a number from 0 to 12.")
            print()

            self.inputSpeed = float(self.inputSpeed)
            self.inputColor = float(self.inputColor)
            self.inputResize = float(self.inputResize)
    def get_video_files(self, folderPath):
        videoExtensions = ['*.mp4', '*.avi', '*.mov', '*.mkv', '*.wmv', '*.flv', '*.webm', '*.mpeg', '*.mpg', '*.3gp']
        videoFiles = []
        for extension in videoExtensions:
            videoFiles.extend(glob.glob(os.path.join(folderPath, extension)))
        return videoFiles
    def selectFolder(self):
        mp4Files = []
        while len(mp4Files) == 0:
            folderPath = filedialog.askdirectory()
            mp4Files = self.get_video_files(folderPath)
            if len(mp4Files) == 0:
                print("<<<<<< Folder Not Found Video file -> Select again >>>>>>")
        return mp4Files

    def run(self):
        options = ["ultrafast", "superfast", "veryfast", "faster", "fast", "medium", "slow", "slower", "veryslow"]
        # Initialize curses
        stdscr = curses.initscr()
        option = curses.wrapper(self.select_option, options)
        curses.endwin()
        self.videoPreset = option
        print("Selected video preset:", option)

        videoMetaTitle = input("input video meta title (default = funny videos): ")
        if len(videoMetaTitle) > 0:
            self.videoMetaTitle = videoMetaTitle

        print("<<<<<< Select folder to edit: >>>>>>")
        mp4Files = self.selectFolder()

        print("<<<<<< Select folder to save: >>>>>>")
        self.folderName = select_folder()

        num_files = len(mp4Files)
        batch_size = 5

        # Print the list of MP4 files
        for i in range(0, num_files, batch_size):
            batch_of_files = mp4Files[i:i + batch_size]
            for file_path in batch_of_files:
                self.editor = Editor(filePath=file_path)
                thread = threading.Thread(target=self.editor.run)
                thread.start()
            thread.join()
        openFolder = messagebox.askyesno(
            "Video processing..", "Do you want to open folder?")
        if openFolder is True:
            os.startfile(self.folderName)


app = App()
app.selectOptions()
app.run()
