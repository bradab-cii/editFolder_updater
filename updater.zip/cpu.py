import concurrent.futures

def worker(index):
    return index * index

def main():
    num_workers_per_loop = 4

    # Generate a list of tasks
    tasks = range(10)

    with concurrent.futures.ThreadPoolExecutor(max_workers=num_workers_per_loop) as executor:
        # Divide the tasks into chunks of size num_workers_per_loop
        for i in range(0, len(tasks), num_workers_per_loop):
            chunk = tasks[i:i + num_workers_per_loop]
            # Submit tasks to the thread pool
            future_to_index = {executor.submit(worker, index): index for index in chunk}
            # Wait for all tasks in the current chunk to complete
            for future in concurrent.futures.as_completed(future_to_index):
                result = future.result()
                print(result)

if __name__ == "__main__":
    main()
